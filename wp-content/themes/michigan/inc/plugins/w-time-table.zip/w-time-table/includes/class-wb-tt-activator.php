<?php

/**
 * Fired during plugin activation
 *
 * @link              http://webnus.biz
 * @since             1.0.0
 * @package           time table
 */

/**
 * Fired during plugin activation.
 */
require_once WB_DIR . 'admin/includes/wb-tt-functions.php' ; 
class Wb_Tt_Activator {

	public static function activate() {

	}

}
